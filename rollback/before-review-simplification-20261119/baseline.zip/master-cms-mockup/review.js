/* Offline, opt-in visual review. This module never edits CMS data or calls an agent. */
window.CMSReview=(()=>{
 'use strict';
 const KEY='master-cms-visual-review-v1',SCHEMA='master-cms-review/1';
 const states={new:'접수',working:'작업 중',ready:'검수 대기',done:'검수 완료',cancelled:'취소'};
 const kinds={layout:'화면·배치',bug:'동작 오류',policy:'업무 정책'};
 const scopes={single:'이 화면의 이 요소',shared:'같은 공통 요소 전체'};
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const clone=x=>JSON.parse(JSON.stringify(x)),time=()=>new Date().toISOString(),uid=()=>crypto.randomUUID();
 const blank=()=>({schema:SCHEMA,revision:0,items:[],draft:null,composers:{}});
 let data=blank(),raw=null,open=false,marking=false,hidden=false,filter='current',selected='',conflict=false,persisted=true,capturing=false,drawing=null,pendingAnchor='',notice='';
 const expanded=new Set(),inertNodes=new Map(),modalOrigins=new WeakMap();let lastAction='';
 try{raw=localStorage.getItem(KEY);if(raw)data=validate(JSON.parse(raw));}catch(e){notice='저장된 검수 자료를 읽지 못했습니다. 원본 저장값을 유지합니다. JSON 내보내기 후 확인하세요.';persisted=false;}
 const ui=document.createElement('div');ui.id='review-ui';ui.dataset.html2canvasIgnore='true';document.body.append(ui);
 const button=(text,act,extra='',cls='')=>`<button type="button" data-rv="${act}" ${extra} class="${cls}">${text}</button>`;
 const terminal=i=>i.status==='done'||i.status==='cancelled';
 const locked=()=>conflict?'disabled':'';
 function validate(v){
  if(!v||v.schema!==SCHEMA||!Array.isArray(v.items)||v.items.length>500||!Number.isInteger(v.revision)||v.revision<0)throw Error('검수 파일 형식이 올바르지 않습니다.');
  const ids=new Set(),nums=new Set();
  function short(x,n=12000){if(typeof x!=='string'||x.length>n)throw Error('문자열 형식 또는 길이를 확인하세요.');return x;}
  function evidence(e){if(e===null||e===undefined)return null;if(typeof e!=='object')throw Error('캡처 형식 오류');return {image:short(e.image,900000),at:short(e.at,40),note:short(e.note,1000)};}
  function context(c){if(!c||typeof c!=='object'||!/^\/[-\w/]*$/.test(c.route)||!Array.isArray(c.modals)||!Array.isArray(c.fields))throw Error('화면 정보 오류');return {route:short(c.route,160),title:short(c.title,300),modals:c.modals.map(x=>short(x,300)),origin:short(c.origin||'',2000),tabs:short(c.tabs,1000),fields:c.fields.slice(0,100).map(x=>({label:short(x.label,200),value:short(x.value,1000)})),scroll:{x:Number(c.scroll?.x)||0,y:Number(c.scroll?.y)||0},viewport:{width:Number(c.viewport?.width)||0,height:Number(c.viewport?.height)||0}};}
  function anchor(a){if(!a)return null;if(typeof a!=='object'||!a.rel||!a.rect)throw Error('영역 형식 오류');const b={selector:short(a.selector,3000),text:short(a.text,300),rel:{},rect:{},tag:short(a.tag,40)};for(const k of ['x','y','w','h']){if(!Number.isFinite(a.rel[k])||!Number.isFinite(a.rect[k]))throw Error('영역 좌표 오류');b.rel[k]=a.rel[k];b.rect[k]=a.rect[k];}return b;}
  function imageSafe(e){if(e?.image&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(e.image))throw Error('PNG·JPEG·WebP 캡처만 허용합니다.');return e;}
  const items=v.items.map(i=>{
   if(!i||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(i.id)||ids.has(i.id)||nums.has(i.number)||!Number.isInteger(i.number)||i.number<1||!Object.hasOwn(states,i.status)||!Object.hasOwn(kinds,i.kind)||!Object.hasOwn(scopes,i.scope))throw Error('요청 번호·상태가 올바르지 않습니다.');ids.add(i.id);nums.add(i.number);
   if(!Array.isArray(i.messages)||i.messages.length>1000)throw Error('대화 이력 오류');
   const sync={};for(const k of ['figma','policy']){const s=i.sync?.[k];if(!s||!['pending','done','na'].includes(s.status))throw Error('후속 반영 정보 오류');sync[k]={status:s.status,evidence:short(s.evidence),at:short(s.at,40)};}
   return {id:short(i.id,100),number:i.number,status:i.status,kind:i.kind,scope:i.scope,request:short(i.request),created:short(i.created,40),updated:short(i.updated,40),captures:(i.captures||[]).slice(0,100).map(e=>imageSafe(evidence(e))),context:context(i.context),anchor:anchor(i.anchor),before:imageSafe(evidence(i.before)),after:imageSafe(evidence(i.after)),sync,messages:i.messages.map(m=>({kind:short(m.kind,40),text:short(m.text),at:short(m.at,40)}))};
  });
  let draft=null;if(v.draft){const d=v.draft;draft={request:short(d.request),kind:Object.hasOwn(kinds,d.kind)?d.kind:'layout',scope:Object.hasOwn(scopes,d.scope)?d.scope:'single',context:context(d.context),anchor:anchor(d.anchor),before:imageSafe(evidence(d.before))};}
  const composers={};for(const [id,c] of Object.entries(v.composers||{})){if(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id))composers[id]={note:short(c.note||''),result:short(c.result||''),proof:short(c.proof||'')};}
  return {schema:SCHEMA,revision:v.revision,items,draft,composers};
 }
 function save(){
  if(conflict)return false;
  try{const latest=localStorage.getItem(KEY);if(latest!==raw){conflict=true;notice='다른 탭의 변경이 있습니다. 현재 내용을 내보낸 뒤 최신 자료를 불러오세요.';return false;}data.revision++;const next=JSON.stringify(data);localStorage.setItem(KEY,next);raw=next;persisted=true;return true;}
  catch(e){persisted=false;notice='브라우저 저장에 실패했습니다. 현재 탭의 자료를 JSON으로 내보내세요. 캡처가 많으면 저장 용량이 부족할 수 있습니다.';return false;}
 }
 function say(text){notice=text;const box=ui.querySelector('.rv-status');if(box)box.textContent=text;}
 function download(name,value){CMS.download(name,JSON.stringify(value,null,2),'application/json');}
 function archiveAfter(i){if(i.after?.image){i.captures||=[];i.captures.push(i.after);}i.after=null;}
 function append(i,kind,text){i.messages.push({kind,text,at:time()});i.updated=time();}
 function ctx(){
  const modals=[...document.querySelectorAll('#modal-root [role=dialog]')].map(x=>x.getAttribute('aria-label')||x.querySelector('h2')?.textContent||'팝업');
  const root=document.querySelector('#modal-root .modal-overlay:last-child')||document.querySelector('main');
  return {origin:[...document.querySelectorAll('#modal-root .modal-overlay')].map(m=>modalOrigins.get(m)||'').join(' → '),route:CMS.current||location.hash.slice(1)||'/home',title:document.querySelector('h1')?.textContent||'',modals,tabs:[...document.querySelectorAll('main [role=tab][aria-selected=true],main .edit-tabs .active,main .tabs .active')].map(x=>x.textContent.trim()).join(' / '),fields:[...(root?.querySelectorAll('input:not([type=file]):not([type=password]),select,textarea')||[])].slice(0,100).filter(x=>x.type!=='hidden').map(x=>({label:(x.getAttribute('aria-label')||x.name||x.dataset.bind||x.id||x.tagName).slice(0,200),value:(x.type==='checkbox'||x.type==='radio'?(x.checked?'선택: ':'해제: '):'')+String(x.value).slice(0,950)})),scroll:{x:scrollX,y:scrollY},viewport:{width:innerWidth,height:innerHeight}};
 }
 const contextKey=c=>JSON.stringify([c.route,c.modals,c.tabs,c.origin]);
 const sameContext=i=>contextKey(i.context)===contextKey(ctx());
 function selector(el){
  const parts=[];for(let n=el;n&&n!==document.body;n=n.parentElement){
   if(n.id&&!/^field-|^modal-fn-/.test(n.id)){parts.unshift('#'+CSS.escape(n.id));break;}
   let part=n.tagName.toLowerCase();const attr=['data-judgment','data-action','data-bind','name'].find(k=>n.hasAttribute(k));
   if(attr)part+='['+attr+'='+JSON.stringify(n.getAttribute(attr))+']';
   const siblings=n.parentElement?[...n.parentElement.children].filter(x=>x.tagName===n.tagName):[];
   if(siblings.length>1)part+=`:nth-of-type(${siblings.indexOf(n)+1})`;parts.unshift(part);
  }return parts.join(' > ');
 }
 function targetAt(x,y){
  // Inert nodes are excluded from hit testing. Briefly unlock synchronously for lookup only.
  for(const el of inertNodes.keys())el.inert=false;
  try{return document.elementsFromPoint(x,y).find(e=>!ui.contains(e)&&e!==document.body&&e!==document.documentElement);}
  finally{for(const el of inertNodes.keys())el.inert=true;}
 }
 function makeAnchor(rect){
  let el=targetAt(rect.x+rect.w/2,rect.y+rect.h/2);if(!el)el=document.querySelector('main');
  const b=el.getBoundingClientRect();return {selector:selector(el),tag:el.tagName,text:(el.textContent||'').trim().replace(/\s+/g,' ').slice(0,300),rel:{x:(rect.x-b.x)/(b.width||1),y:(rect.y-b.y)/(b.height||1),w:rect.w/(b.width||1),h:rect.h/(b.height||1)},rect};
 }
 function resolve(i){
  if(!i.anchor||!sameContext(i))return null;
  let el;try{el=document.querySelector(i.anchor.selector);}catch(e){return null;}
  if(!el||!el.getClientRects().length||el.tagName!==i.anchor.tag)return null;
  const t=(el.textContent||'').trim().replace(/\s+/g,' ').slice(0,300);if(i.anchor.text&&t!==i.anchor.text)return null;
  const b=el.getBoundingClientRect(),r=i.anchor.rel;return {x:b.x+r.x*b.width,y:b.y+r.y*b.height,w:r.w*b.width,h:r.h*b.height};
 }
 function marks(){
  const layer=ui.querySelector('.rv-marks');if(!layer)return;layer.innerHTML='';
  if(hidden)return;
  if(data.draft?.anchor){const r=resolve(data.draft);if(r){const m=document.createElement('div');m.className='rv-mark';Object.assign(m.style,{left:r.x+'px',top:r.y+'px',width:r.w+'px',height:r.h+'px'});m.innerHTML='<span class="rv-num">'+(Math.max(0,...data.items.map(x=>x.number))+1)+'</span>';layer.append(m);}}
  for(const i of data.items.filter(i=>!terminal(i))){const r=resolve(i);if(!r)continue;const m=document.createElement('div');m.className='rv-mark'+(i.id===selected?' rv-selected':'');Object.assign(m.style,{left:r.x+'px',top:r.y+'px',width:r.w+'px',height:r.h+'px'});m.innerHTML=`<button type="button" class="rv-num" data-rv="focus" data-id="${i.id}" aria-label="수정 요청 ${i.number}번 보기">${i.number}</button>`;layer.append(m);}
 }
 function mask(){
  if(marking){for(const el of [...document.body.children].filter(x=>x!==ui&&x.tagName!=='SCRIPT')){if(!inertNodes.has(el))inertNodes.set(el,el.inert);el.inert=true;}if(!ui.contains(document.activeElement))document.activeElement?.blur();}
  else{for(const [el,was]of inertNodes)el.inert=was;inertNodes.clear();}
 }
 function switchMark(value){marking=!!value&&!conflict;if(!marking)pendingAnchor='';if(marking)hidden=false;drawing=null;mask();render();}
 function snapshotHtml(e,label){return e?.image?`<a href="${esc(e.image)}" target="_blank" rel="noopener" aria-label="${label} 캡처 크게 보기"><img src="${esc(e.image)}" alt="${label} 화면 캡처"></a>`:'<div class="rv-no-image">캡처 없음</div>';}
 function evidenceHtml(i){return `<details class="rv-evidence"><summary>수정 전·후 비교</summary><div class="rv-evidence-grid"><figure>${snapshotHtml(i.before,'수정 전')}<figcaption>수정 전 · ${esc(i.before?.at?.slice(0,16)||'미기록')}</figcaption></figure><figure>${snapshotHtml(i.after,'수정 후')}<figcaption>수정 후 · ${esc(i.after?.at?.slice(0,16)||'미기록')}</figcaption></figure></div><p class="rv-capture-limit">${esc(i.before?.note||'')}\n${esc(i.after?.note||'')}</p>${i.captures?.length?'<details><summary>이전 수정 캡처 '+i.captures.length+'개</summary>'+i.captures.map(e=>'<figure>'+snapshotHtml(e,'이전 수정')+'<figcaption>'+esc(e.at)+'</figcaption></figure>').join('')+'</details>':''}</details>`;}
 function options(values,current){return Object.entries(values).map(([k,v])=>`<option value="${k}" ${k===current?'selected':''}>${v}</option>`).join('');}
 function card(i){
  const compose=data.composers[i.id]||{},editable=!terminal(i),region=i.anchor?(resolve(i)?'현재 화면에서 영역을 찾았습니다.':'현재 화면에서 영역을 찾지 못했습니다. 화면·팝업 상태를 맞추거나 영역을 다시 지정하세요.'):'영역 표시 없음';
  return `<details class="rv-card" data-id="${esc(i.id)}" ${expanded.has(i.id)?'open':''}><summary><span class="rv-num">${i.number}</span><span class="rv-summary"><strong>${esc(i.request.slice(0,56))}</strong><small>${states[i.status]} · ${kinds[i.kind]} · ${esc(i.context.title)}</small></span></summary><div class="rv-card-body"><p class="rv-meta">${esc(i.context.route)}${i.context.modals.length?'\n팝업: '+esc(i.context.modals.join(' → ')):''}\n${scopes[i.scope]}\n${region}</p><div class="rv-actions">${button('화면으로 이동','locate','data-id="'+i.id+'"')}${editable?button('영역 다시 지정','reanchor',`data-id="${i.id}" ${locked()}`):''}</div><details><summary>요청 당시 화면 상태</summary><pre class="rv-meta">${esc(JSON.stringify(i.context,null,2))}</pre></details>${i.messages.map(m=>`<div class="rv-message" data-kind="${esc(m.kind)}"><small>${esc(({request:'수정 요청',comment:'검토 의견',result:'작업 결과',approval:'사용자 검수',rework:'재작업 요청',system:'이력'})[m.kind]||m.kind)} · ${esc(m.at.slice(0,16))}</small>${esc(m.text)}</div>`).join('')}${evidenceHtml(i)}<label class="rv-file">수정 전 실제 캡처 첨부<input type="file" accept="image/png,image/jpeg,image/webp" data-attach="${i.id}" data-slot="before" ${!editable?'disabled':locked()}></label>
   ${editable?`<label>추가 의견<textarea data-note maxlength="12000" placeholder="Enter로 등록 · Shift+Enter로 줄바꿈" ${locked()}>${esc(compose.note||'')}</textarea></label><div class="rv-actions">${button('의견 등록','comment',`data-id="${i.id}" ${locked()}`)}${i.status==='new'?button('작업 시작 기록','start',`data-id="${i.id}" ${locked()}`):''}</div>
    <details class="rv-result"><summary>작업 결과 기록</summary><p class="rv-help">실제 파일을 수정한 뒤 요약과 확인 근거를 기록하세요. 이 버튼은 코드를 자동 수정하지 않습니다. 작업자 결과 JSON도 가져올 수 있습니다.</p><label>수정 내용<textarea data-result maxlength="12000" ${locked()}>${esc(compose.result||'')}</textarea></label><label>확인 근거 (파일·검증 결과)<textarea data-result-proof maxlength="12000" ${locked()}>${esc(compose.proof||'')}</textarea></label><div class="rv-actions">${button('검수 요청','result',`data-id="${i.id}" ${locked()}`)}</div></details>
    <div class="rv-actions">${button('현재 화면을 수정 후로 캡처','capture-after',`data-id="${i.id}" ${locked()}`)}</div><label class="rv-file">수정 후 실제 캡처 첨부<input type="file" accept="image/png,image/jpeg,image/webp" data-attach="${i.id}" data-slot="after" ${locked()}></label>
    <div class="rv-actions">${i.status==='ready'?button('수정 확인 · 완료','approve',`data-id="${i.id}" ${locked()}`,'rv-primary')+button('재작업 요청','rework',`data-id="${i.id}" ${locked()}`):''}${button('영역 삭제','detach',`data-id="${i.id}" ${!i.anchor?'disabled':locked()}`)}${button('요청 취소','cancel',`data-id="${i.id}" ${locked()}`,'rv-danger')}</div>`:
    `<div class="rv-actions">${button('다시 열기','reopen',`data-id="${i.id}" ${locked()}`)}</div>`}
    ${i.status==='done'?`<div class="rv-sync"><strong>후속 반영</strong><p class="rv-help">사용자 검수와 별도로 관리합니다. 실제 반영한 링크·파일·근거를 입력해야 완료로 기록됩니다.</p>${['figma','policy'].map(k=>`<label>${k==='figma'?'Figma':'정책·기록 문서'}<select data-sync="${k}" ${locked()}>${options({pending:'반영 대기',done:'반영 완료',na:'해당 없음'},i.sync[k].status)}</select></label><label>반영 근거<input data-sync-proof="${k}" value="${esc(i.sync[k].evidence)}" maxlength="12000" ${locked()}></label>${button('반영 상태 기록','sync',`data-id="${i.id}" data-kind="${k}" ${locked()}`)}`).join('')}</div>`:''}
   </div></details>`;
 }
 function render(){
  const scroll=ui.querySelector('.rv-scroll')?.scrollTop||0;
  document.body.classList.toggle('review-open',open);document.body.classList.toggle('review-marking',open&&marking);
  if(!open){ui.innerHTML=`<button type="button" data-rv="open" class="rv-launch" aria-label="화면 검수 도구 열기"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m15 4 5 5M4 20l5-1L21 7l-4-4L5 15zM4 20h16"/></svg>화면 검수</button>`;return;}
  const current=ctx(),active=data.items.filter(i=>!terminal(i)).length;
  const list=data.items.filter(i=>filter==='all'||filter==='done'?filter==='all'||terminal(i):!terminal(i)&&(filter!=='current'||i.context.route===current.route));
  ui.innerHTML=`<div class="rv-marks" aria-hidden="true"></div>${marking?'<div class="rv-blocker" aria-label="검수 영역을 드래그하여 지정" role="img"></div>':''}<aside class="rv-panel" aria-label="화면 검수 패널"><header class="rv-header"><div class="rv-title"><h2>화면 검수</h2>${button('닫기','close','aria-label="검수 도구 닫기"')}</div><p>${marking?'영역 지정 중 · CMS 입력이 잠겼습니다.':'화면 조작 중 · CMS를 평소처럼 사용하세요.'}</p><div class="rv-toolbar">${button(marking?'영역 지정 끝내기':'펜 · 영역 지정','mark',`aria-pressed="${marking}" ${data.draft?'disabled':locked()}`,'rv-primary')}${button(hidden?'표시 다시 보기':'표시 숨기기','hide',`aria-pressed="${hidden}"`)}</div><div class="rv-toolbar">${button('요청 내보내기','export')}${button('가져오기','import',locked())}${button('도움말','help')}</div></header><p class="rv-status" role="status" aria-live="polite">${esc(!persisted?'브라우저 저장에 실패했습니다. 현재 탭의 자료를 JSON으로 내보내세요.':notice)}</p>${conflict?`<div class="rv-header">${button('최신 자료 불러오기','reload')}</div>`:''}<div class="rv-scroll">
    ${data.draft?`<section class="rv-draft"><h3>새 수정 요청</h3><p class="rv-meta">${esc(data.draft.context.title)} · 영역 ${data.draft.anchor?'지정됨':'없음'}</p><label for="rv-request">수정할 내용</label><textarea id="rv-request" data-draft="request" maxlength="12000" placeholder="어떤 상태에서 무엇을 어떻게 바꿀지 입력하세요." ${locked()}>${esc(data.draft.request)}</textarea><label for="rv-kind">변경 구분</label><select id="rv-kind" data-draft="kind" ${locked()}>${options(kinds,data.draft.kind)}</select><label for="rv-scope">적용 범위</label><select id="rv-scope" data-draft="scope" ${locked()}>${options(scopes,data.draft.scope)}</select><div class="rv-actions">${button('요청 등록','create',locked(),'rv-primary')}${button('작성 취소','discard-draft',locked())}</div></section>`:''}
    <div class="rv-section"><label for="rv-filter">요청 목록 · 진행 ${active} / 전체 ${data.items.length}</label><select id="rv-filter" data-filter>${options({current:'현재 페이지 · 진행 중',active:'전체 페이지 · 진행 중',done:'완료·취소된 작업',all:'전체 이력'},filter)}</select><div class="rv-actions">${button('영역 없이 요청','page-request',data.draft?'disabled':locked())}${button('작업 전달 파일','packet',locked())}</div><div class="rv-actions">${button(filter==='done'?'진행 중인 작업 보기':'완료된 작업 보기','completed')}</div></div>
    ${list.length?list.map(card).join(''):'<div class="rv-empty"><strong>등록된 요청이 없습니다.</strong>화면을 필요한 상태로 연 다음 펜 버튼을 누르고 수정할 영역을 드래그하세요.</div>'}
    <p class="rv-help">등록만으로 파일이나 Figma가 수정되지는 않습니다. 작업 전달 파일을 이 대화에 첨부하면 요청 번호별로 작업을 이어갈 수 있습니다.</p>
   </div></aside>`;
  ui.querySelector('.rv-scroll').scrollTop=scroll;marks();
 }
 async function capture(){
  if(capturing)throw Error('캡처가 진행 중입니다.');capturing=true;
  const width=Math.max(1,innerWidth-(open&&innerWidth>1000?380:0)),height=innerHeight;
  try{
   const canvas=await html2canvas(document.body,{logging:false,scale:Math.min(1,1000/width),x:scrollX,y:scrollY,width,height,windowWidth:innerWidth,windowHeight:innerHeight,backgroundColor:'#fafafa',allowTaint:false,useCORS:false,imageTimeout:1200,ignoreElements:el=>el.id==='review-ui'||el.tagName==='SCRIPT',onclone:doc=>{
    doc.querySelectorAll('iframe,canvas,video,math-field').forEach(el=>{const d=doc.createElement('div'),r=el.getBoundingClientRect();d.textContent=el.tagName==='IFRAME'?'외부/격리 프레임 · 실제 화면 캡처 첨부 권장':'특수 편집 영역 · 실제 화면 캡처 첨부 권장';d.style.cssText=`width:${r.width}px;height:${r.height}px;background:#edf0f3;border:1px dashed #a7b2bf;color:#45596b;padding:12px;overflow:hidden`;el.replaceWith(d);});
    doc.querySelectorAll('img').forEach(img=>{if(/^https?:/.test(img.getAttribute('src')||''))img.removeAttribute('src');});
   }});
   return {image:canvas.toDataURL('image/jpeg',.72),at:time(),note:'DOM 참고 캡처입니다. iframe·수식 편집·일부 이미지와 글꼴은 실제 화면과 다를 수 있습니다. 정확한 비교는 실제 캡처를 첨부하세요.'};
  }catch(e){return {image:'',at:time(),note:'자동 캡처 실패: '+String(e.message).slice(0,200)+' · 브라우저 실제 화면 캡처를 첨부하세요.'};}
  finally{capturing=false;}
 }
 function find(id){return data.items.find(i=>i.id===id);}
 function panelFor(id){return [...ui.querySelectorAll('.rv-card')].find(x=>x.dataset.id===id);}
 async function act(act,b){
  const id=b?.dataset.id,i=find(id),p=panelFor(id);
  if(conflict&&!['export','reload','help','close','open','hide','locate','focus','completed'].includes(act))return say('다른 탭의 변경을 먼저 확인하세요.');
  if(act==='open'){open=true;render();}
  else if(act==='close'){open=false;pendingAnchor='';switchMark(false);}
  else if(act==='mark'){if(data.draft)return;switchMark(!marking);}
  else if(act==='hide'){hidden=!hidden;if(hidden){marking=false;pendingAnchor='';}mask();render();}
  else if(act==='completed'){filter=filter==='done'?'active':'done';render();}
  else if(act==='focus'){selected=id;expanded.add(id);filter='active';render();panelFor(id)?.scrollIntoView({block:'nearest'});}
  else if(act==='help'){say('① 화면·팝업을 원하는 상태로 엽니다. ② 펜으로 영역을 그려 요청을 등록합니다. ③ 작업 전달 JSON을 이 대화에 첨부합니다. ④ 실제 수정 후 결과를 기록하고 화면을 검수합니다. ⑤ 완료하면 영역은 숨겨지고 이력은 보존됩니다. Figma·정책은 별도 근거로 반영 상태를 기록합니다.');}
  else if(act==='export'){download('master-cms-review-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json',data);}
  else if(act==='packet'){
   const items=data.items.filter(i=>!terminal(i));if(!items.length)return say('전달할 진행 중 요청이 없습니다.');
   download('master-cms-review-work.json',{schema:'master-cms-review-work/1',exported:time(),baseRevision:data.revision,instructions:'요청 번호와 ID를 유지하세요. 실제 소스 수정·검증 후 review_cli.py로 결과 파일을 생성하고 UI에서 가져옵니다. CMS 관찰 사실과 제안 정책을 구분하고 사용자 검수를 대신 완료하지 마세요.',items:clone(items)});say('작업 전달 파일을 내보냈습니다. 이 대화에 첨부하면 실제 파일 수정을 이어갈 수 있습니다.');
  }
  else if(act==='import'){const f=document.createElement('input');f.type='file';f.accept='.json,application/json';f.onchange=async()=>{if(f.files[0])await importFile(f.files[0]);};f.click();}
  else if(act==='reload'){if(!window.confirm('현재 탭의 검수 내용을 최신 저장값으로 바꾸시겠습니까? 필요한 내용은 먼저 내보내세요.'))return;try{const latest=localStorage.getItem(KEY),v=latest?validate(JSON.parse(latest)):blank();data=v;raw=latest;conflict=false;persisted=true;notice='최신 검수 자료를 불러왔습니다.';render();}catch(e){say(e.message);}}
  else if(act==='page-request'){data.draft={request:'',kind:'layout',scope:'single',context:ctx(),anchor:null,before:await capture()};save();render();ui.querySelector('[data-draft=request]')?.focus();}
  else if(act==='discard-draft'){if(data.draft.request&&!window.confirm('작성 중인 요청을 취소하시겠습니까?'))return;data.draft=null;save();render();}
  else if(act==='create'){
   const d=data.draft;if(!d?.request.trim())return say('수정할 내용을 입력하세요.');
   const now=time(),number=Math.max(0,...data.items.map(x=>x.number))+1;
   const n={...clone(d),id:uid(),number,request:d.request.trim(),status:'new',created:now,updated:now,after:null,captures:[],messages:[{kind:'request',text:d.request.trim(),at:now}],sync:{figma:{status:'pending',evidence:'',at:''},policy:{status:d.kind==='policy'?'pending':'na',evidence:d.kind==='policy'?'':'업무 정책 변경 없음',at:''}}};
   data.items.push(n);data.draft=null;expanded.add(n.id);selected=n.id;save();notice='요청을 등록했습니다. 작업 전달 파일을 내보내 이 대화에 첨부할 수 있습니다.';render();
  }
  else if(i){
   if(act==='locate'){
    selected=i.id;if(!sameContext(i)){if(i.context.route!==CMS.current)CMS.go(i.context.route);say('해당 페이지로 이동합니다. 기록된 팝업·탭·입력 상태는 화면 상태 목록을 보고 직접 맞춰 주세요. 미저장 CMS 입력의 확인 절차는 유지됩니다.');}
    else{let el;try{el=document.querySelector(i.anchor?.selector||'main');}catch(e){}el?.scrollIntoView({block:'center',behavior:'instant'});say(resolve(i)?'연결된 영역을 표시했습니다.':'연결된 요소를 찾지 못했습니다. 영역을 다시 지정할 수 있습니다.');}marks();return;
   }
   if(terminal(i)&&!['reopen','sync'].includes(act))return;
   if(act==='reanchor'){pendingAnchor=id;hidden=false;switchMark(true);say('새 영역을 드래그하세요. 이전 캡처와 요청 이력은 유지됩니다.');return;}
   if(act==='comment'){const t=p.querySelector('[data-note]').value.trim();if(!t)return say('의견을 입력하세요.');append(i,'comment',t);if(data.composers[i.id])data.composers[i.id].note='';}
   else if(act==='start'){i.status='working';append(i,'system','작업 시작을 기록했습니다. 실제 코드 수정은 작업자가 수행합니다.');}
   else if(act==='result'){
    const summary=p.querySelector('[data-result]').value.trim(),proof=p.querySelector('[data-result-proof]').value.trim();if(!summary||!proof)return say('수정 내용과 확인 근거를 모두 입력하세요.');i.status='ready';append(i,'result',summary+'\n확인 근거: '+proof);archiveAfter(i);data.composers[i.id]={note:'',result:'',proof:''};
   }
   else if(act==='capture-after'){if(!sameContext(i))return say('요청 당시 페이지·탭·팝업 상태에서 캡처하세요.');say('수정 후 참고 화면을 캡처하고 있습니다.');archiveAfter(i);i.after=await capture();append(i,'system','수정 후 참고 화면을 캡처했습니다.');}
   else if(act==='approve'){
    if(i.status!=='ready')return;if(!i.after?.image)return say('수정 후 화면을 캡처하거나 실제 캡처를 첨부한 뒤 완료하세요.');
    if(!window.confirm('실제 수정 화면과 동작을 확인했습니까? 완료하면 빨간 영역은 숨기고 요청·결과 이력은 보존합니다.'))return;
    i.status='done';append(i,'approval','사용자가 수정 결과를 확인하고 완료했습니다. Figma·정책 반영은 별도로 추적합니다.');
   }
   else if(act==='rework'){
    const t=p.querySelector('[data-note]').value.trim();if(!t)return say('추가 의견에 재작업 사유를 입력하세요.');i.status='working';archiveAfter(i);append(i,'rework',t);
   }
   else if(act==='detach'){i.anchor=null;append(i,'system','영역 표시를 삭제했습니다. 요청은 유지됩니다.');}
   else if(act==='cancel'){if(!window.confirm('요청을 취소하시겠습니까? 이력은 보존됩니다.'))return;i.status='cancelled';append(i,'system','사용자가 요청을 취소했습니다.');}
   else if(act==='reopen'){i.status='new';archiveAfter(i);for(const s of Object.values(i.sync))if(s.status==='done')s.status='pending';append(i,'system','요청을 다시 열었습니다. 기존 반영 근거는 이력으로 유지하고 재검수가 필요합니다.');filter='active';}
   else if(act==='sync'){
    if(i.status!=='done')return;const k=b.dataset.kind,status=p.querySelector(`[data-sync=${k}]`).value,proof=p.querySelector(`[data-sync-proof=${k}]`).value.trim();
    if(status!=='pending'&&!proof)return say('반영 완료 또는 해당 없음의 근거를 입력하세요.');i.sync[k]={status,evidence:proof,at:time()};append(i,'system',`${k==='figma'?'Figma':'정책·기록 문서'}: ${{pending:'반영 대기',done:'반영 완료',na:'해당 없음'}[status]}\n근거: ${proof}`);
   }else return;
   save();render();
  }
 }
 async function importFile(file){
  try{
   if(file.size>16*1024*1024)throw Error('16MB 이하의 JSON을 선택하세요.');const v=JSON.parse(await file.text());
   if(v.schema==='master-cms-review-result/1'){
    if(!Array.isArray(v.results)||!v.results.length)throw Error('작업 결과가 없습니다.');const next=clone(data),seen=new Set();
    for(const r of v.results){const i=next.items.find(x=>x.id===r.id);if(!i||terminal(i)||seen.has(r.id)||r.baseUpdated!==i.updated)throw Error('대상 요청이 변경되었거나 완료됐습니다. 최신 작업 전달 파일로 다시 작성하세요.');if(typeof r.summary!=='string'||!r.summary.trim()||typeof r.evidence!=='string'||!r.evidence.trim()||r.summary.length+r.evidence.length>12000)throw Error('수정 요약과 확인 근거가 필요합니다.');seen.add(r.id);i.status='ready';archiveAfter(i);append(i,'result',r.summary+'\n확인 근거: '+r.evidence);}
    data=validate(next);save();notice=`작업 결과 ${v.results.length}건을 가져왔습니다. 실제 화면을 확인하고 완료하세요.`;
   }else{
    const incoming=validate(v),next=clone(data);if(data.draft&&incoming.draft)throw Error('현재 작성 중인 요청을 등록하거나 취소한 뒤 가져오세요.');
    const used=new Set(next.items.map(i=>i.number));for(const i of incoming.items){const old=next.items.find(x=>x.id===i.id);if(old){if(JSON.stringify(i)!==JSON.stringify(old))throw Error('같은 ID의 다른 이력이 있습니다. 병합으로 덮어쓰지 않습니다. 별도 파일로 보관해 비교하세요.');}else{if(used.has(i.number)){i.number=Math.max(0,...used)+1;}used.add(i.number);next.items.push(i);}}
    for(const [id,c]of Object.entries(incoming.composers)){
     const old=next.composers[id]||{};if(['note','result','proof'].some(k=>old[k]&&c[k]&&old[k]!==c[k]))throw Error('같은 요청의 미등록 입력이 다릅니다. 현재 입력을 별도로 내보내고 비교하세요.');
     next.composers[id]={note:old.note||c.note||'',result:old.result||c.result||'',proof:old.proof||c.proof||''};
    }
    if(incoming.draft)next.draft=incoming.draft;data=validate(next);save();notice='검수 자료를 병합했습니다. 기존 이력은 덮어쓰지 않았습니다.';
   }render();
  }catch(e){say('가져오기 실패: '+e.message);}
 }
 ui.addEventListener('click',e=>{const b=e.target.closest('[data-rv]');if(!b||b.disabled)return;e.preventDefault();act(b.dataset.rv,b).catch(err=>say('작업을 마치지 못했습니다: '+err.message));});
 ui.addEventListener('input',e=>{const t=e.target;if(!conflict&&t.matches('[data-note],[data-result],[data-result-proof]')){const id=t.closest('.rv-card').dataset.id;data.composers[id]||={note:'',result:'',proof:''};data.composers[id][t.hasAttribute('data-note')?'note':t.hasAttribute('data-result')?'result':'proof']=t.value;save();}if(e.target.dataset.draft&&data.draft&&!conflict){data.draft[e.target.dataset.draft]=e.target.value;save();}});
 ui.addEventListener('change',async e=>{
  if(e.target.matches('[data-filter]')){filter=e.target.value;render();}
  if(e.target.dataset.draft&&data.draft&&!conflict){data.draft[e.target.dataset.draft]=e.target.value;save();}
  if(e.target.dataset.attach&&!conflict){const i=find(e.target.dataset.attach),file=e.target.files[0];if(!i||terminal(i)||!file)return;if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>5*1024*1024)return say('5MB 이하의 PNG·JPEG·WebP를 선택하세요.');
   try{const bitmap=await createImageBitmap(file),canvas=document.createElement('canvas'),scale=Math.min(1,1200/bitmap.width);canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();const slot=e.target.dataset.slot;if(slot==='after')archiveAfter(i);i[slot]={image:canvas.toDataURL('image/jpeg',.75),at:time(),note:'사용자가 첨부한 실제 화면 캡처의 사본입니다. 최대 1200px 폭으로 줄이고 JPEG로 압축했습니다. 원본은 별도로 보관하세요.'};append(i,'system',(slot==='before'?'수정 전':'수정 후')+' 실제 화면 캡처를 첨부했습니다.');save();render();}catch(err){say('이미지를 읽지 못했습니다. 다른 캡처를 선택하세요.');}
  }
 });
 ui.addEventListener('toggle',e=>{if(e.target.matches('.rv-card')){if(e.target.open)expanded.add(e.target.dataset.id);else expanded.delete(e.target.dataset.id);}},true);
 ui.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.target.matches('[data-note]')){e.preventDefault();act('comment',{dataset:{id:e.target.closest('.rv-card').dataset.id}});}});
 ui.addEventListener('pointerdown',e=>{
  if(!e.target.matches('.rv-blocker')||e.button!==0||data.draft||capturing)return;e.preventDefault();
  drawing={x:e.clientX,y:e.clientY,endX:e.clientX,endY:e.clientY,id:e.pointerId};e.target.setPointerCapture(e.pointerId);const box=document.createElement('div');box.className='rv-drawing';ui.append(box);
 });
 ui.addEventListener('pointermove',e=>{if(!drawing)return;drawing.endX=Math.max(0,Math.min(e.clientX,ui.querySelector('.rv-blocker').getBoundingClientRect().right));drawing.endY=Math.max(0,Math.min(e.clientY,innerHeight));const b=ui.querySelector('.rv-drawing');Object.assign(b.style,{left:Math.min(drawing.x,drawing.endX)+'px',top:Math.min(drawing.y,drawing.endY)+'px',width:Math.abs(drawing.x-drawing.endX)+'px',height:Math.abs(drawing.y-drawing.endY)+'px'});});
 ui.addEventListener('pointerup',async e=>{
  if(!drawing||drawing.id!==e.pointerId)return;const d=drawing;drawing=null;ui.querySelector('.rv-drawing')?.remove();const rect={x:Math.min(d.x,d.endX),y:Math.min(d.y,d.endY),w:Math.abs(d.x-d.endX),h:Math.abs(d.y-d.endY)};if(rect.w<8||rect.h<8)return say('가로·세로 8px 이상 드래그하세요.');
  const anchor=makeAnchor(rect),context=ctx();marking=false;mask();render();
  if(pendingAnchor){const i=find(pendingAnchor);pendingAnchor='';if(i&&!terminal(i)){i.anchor=anchor;i.context=context;append(i,'system','연결 영역과 화면 상태를 다시 지정했습니다. 최초 캡처는 유지합니다.');save();render();}return;}
  say('요청 당시 참고 화면을 캡처하고 있습니다.');const before=await capture();data.draft={request:'',kind:'layout',scope:'single',context,anchor,before};save();notice='수정할 내용을 입력하고 요청을 등록하세요.';render();ui.querySelector('[data-draft=request]')?.focus();
 });
 ui.addEventListener('pointercancel',()=>{drawing=null;ui.querySelector('.rv-drawing')?.remove();});
 // Capture guard also stops CMS's delegated shortcuts while the review panel has focus.
 for(const type of ['click','dblclick','keydown','keyup','keypress','submit','dragstart','drop','paste'])window.addEventListener(type,e=>{
  if(!open)return;
  if(type==='keydown'&&e.key==='Escape'&&marking){e.preventDefault();e.stopImmediatePropagation();pendingAnchor='';switchMark(false);return;}
  if(ui.contains(e.target)){e.stopPropagation();return;}
  if(marking){e.preventDefault();e.stopImmediatePropagation();}
 },{capture:false});
 // CMS handlers are on document. A capture-phase fence prevents them from seeing panel events.
 document.addEventListener('keydown',e=>{if(ui.contains(e.target)){if(e.key==='Escape'&&marking){e.preventDefault();pendingAnchor='';switchMark(false);}e.stopPropagation();if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.target.matches('[data-note]')){e.preventDefault();act('comment',{dataset:{id:e.target.closest('.rv-card').dataset.id}});} }else if(marking){if(e.key==='Escape'){pendingAnchor='';switchMark(false);}e.preventDefault();e.stopImmediatePropagation();}},true);
 let queued=false;function refresh(){if(!open||queued)return;queued=true;requestAnimationFrame(()=>{queued=false;mask();marks();});}
 document.addEventListener('click',e=>{if(ui.contains(e.target))return;const b=e.target.closest('[data-action]');if(b)lastAction=JSON.stringify({action:b.dataset.action,context:b.dataset.context||'',id:b.dataset.id||'',tab:b.dataset.tab||'',label:b.textContent.trim().slice(0,100)});},true);
 const observer=new MutationObserver(records=>{if(records.some(r=>!ui.contains(r.target))){for(const m of document.querySelectorAll('#modal-root .modal-overlay'))if(!modalOrigins.has(m))modalOrigins.set(m,lastAction);refresh();}});observer.observe(document.body,{childList:true,subtree:true});
 window.addEventListener('scroll',refresh,true);window.addEventListener('resize',refresh);
 window.addEventListener('hashchange',()=>{marking=false;pendingAnchor='';mask();setTimeout(()=>{if(open)render();},60);});
 window.addEventListener('storage',e=>{if(e.key===KEY&&e.newValue!==raw){conflict=true;marking=false;mask();notice='다른 탭에서 검수 자료가 변경됐습니다. 현재 자료를 내보낸 뒤 최신 자료를 불러오세요.';render();}});
 render();
 return {exportData:()=>clone(data),validate,importFile,open:()=>{open=true;render();}};
})();
